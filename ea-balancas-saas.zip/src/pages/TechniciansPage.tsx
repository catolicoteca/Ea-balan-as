import React, { useCallback, useEffect, useState } from 'react';
import {
  Wrench,
  Plus,
  Edit3,
  ShieldCheck,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthTenant } from '../contexts/AuthTenantContext';
import { translateSupabaseError } from '../lib/errors';
import {
  formatCPF,
  formatPhone,
  technicianSchema,
  zodErrorsToMap,
} from '../lib/validation';
import type { Technician } from '../types/database';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import {
  CheckboxField,
  InputField,
  TextareaField,
} from '../components/ui/FormField';
import { AlertBanner, EmptyState } from '../components/ui/EmptyState';

const PRESET_TECH_COLORS = [
  '#0D9488',
  '#0284C7',
  '#4F46E5',
  '#D97706',
  '#059669',
  '#DC2626',
  '#7C3AED',
];

export const TechniciansPage: React.FC = () => {
  const { activeCompany, user, permissions } = useAuthTenant();

  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingTech, setEditingTech] = useState<Technician | null>(null);

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [cpf, setCpf] = useState('');
  const [regCode, setRegCode] = useState('');
  const [specialtiesText, setSpecialtiesText] = useState('');
  const [calendarColor, setCalendarColor] = useState('#0D9488');
  const [canViewAllOS, setCanViewAllOS] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [notes, setNotes] = useState('');

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitErr, setSubmitErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const loadTechnicians = useCallback(async () => {
    if (!activeCompany) return;
    setLoading(true);
    setError(null);

    const { data, error: qErr } = await supabase
      .from('technicians')
      .select('*')
      .eq('company_id', activeCompany.id)
      .order('full_name', { ascending: true });

    if (qErr) {
      setError(translateSupabaseError(qErr));
      setTechnicians([]);
    } else {
      setTechnicians((data as Technician[]) ?? []);
    }
    setLoading(false);
  }, [activeCompany]);

  useEffect(() => {
    void loadTechnicians();
  }, [loadTechnicians]);

  const openNew = () => {
    setEditingTech(null);
    setFullName('');
    setEmail('');
    setPhone('');
    setCpf('');
    setRegCode('');
    setSpecialtiesText('Balanças Comerciais, Plataforma');
    setCalendarColor(
      PRESET_TECH_COLORS[technicians.length % PRESET_TECH_COLORS.length]
    );
    setCanViewAllOS(false);
    setIsActive(true);
    setNotes('');
    setFieldErrors({});
    setSubmitErr(null);
    setModalOpen(true);
  };

  const openEdit = (t: Technician) => {
    setEditingTech(t);
    setFullName(t.full_name);
    setEmail(t.email ?? '');
    setPhone(t.phone ?? '');
    setCpf(t.document_cpf ?? '');
    setRegCode(t.registration_code ?? '');
    setSpecialtiesText((t.specialties ?? []).join(', '));
    setCalendarColor(t.calendar_color || '#0D9488');
    setCanViewAllOS(t.can_view_all_company_os);
    setIsActive(t.is_active);
    setNotes(t.notes ?? '');
    setFieldErrors({});
    setSubmitErr(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCompany) return;

    setFieldErrors({});
    setSubmitErr(null);

    const parsed = technicianSchema.safeParse({
      full_name: fullName,
      email: email || undefined,
      phone: phone || undefined,
      document_cpf: cpf || undefined,
      registration_code: regCode || undefined,
      specialtiesText: specialtiesText || undefined,
      calendar_color: calendarColor,
      can_view_all_company_os: canViewAllOS,
      is_active: isActive,
      notes: notes || undefined,
    });

    if (!parsed.success) {
      setFieldErrors(zodErrorsToMap(parsed.error));
      return;
    }

    const specialties = (parsed.data.specialtiesText ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    setSaving(true);
    const payload = {
      company_id: activeCompany.id,
      full_name: parsed.data.full_name,
      email: parsed.data.email ? parsed.data.email.toLowerCase() : null,
      phone: parsed.data.phone || null,
      document_cpf: parsed.data.document_cpf || null,
      registration_code: parsed.data.registration_code || null,
      specialties,
      calendar_color: parsed.data.calendar_color,
      can_view_all_company_os: parsed.data.can_view_all_company_os,
      is_active: parsed.data.is_active,
      notes: parsed.data.notes || null,
    };

    if (editingTech) {
      const { error: uErr } = await supabase
        .from('technicians')
        .update(payload)
        .eq('id', editingTech.id)
        .eq('company_id', activeCompany.id);

      setSaving(false);
      if (uErr) {
        setSubmitErr(translateSupabaseError(uErr));
        return;
      }
    } else {
      const { data: createdTech, error: iErr } = await supabase
        .from('technicians')
        .insert(payload)
        .select('id, email')
        .single();

      if (iErr) {
        setSaving(false);
        setSubmitErr(translateSupabaseError(iErr));
        return;
      }

      // Se informou e-mail, já registra convite automático para vincular conta Supabase Auth no login/cadastro
      if (createdTech?.email) {
        await supabase.from('company_invitations').insert({
          company_id: activeCompany.id,
          email: createdTech.email.toLowerCase(),
          full_name: parsed.data.full_name,
          role: 'technician',
          technician_id: createdTech.id,
          invited_by: user?.id ?? null,
        });
      }
      setSaving(false);
    }

    setModalOpen(false);
    await loadTechnicians();
  };

  if (!permissions.canManageTechnicians) {
    return (
      <AlertBanner
        variant="warning"
        title="Acesso Restrito ao Gestor"
        message="O módulo de gerenciamento de técnicos é exclusivo para Gestores da empresa e Administradores da plataforma."
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
            Equipe Técnica de Campo
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Cadastro de técnicos, credenciais metrológicas, vínculo de acesso e regras de visibilidade de OS.
          </p>
        </div>

        <Button onClick={openNew} leftIcon={<Plus className="w-4 h-4" />}>
          Novo Técnico
        </Button>
      </div>

      {error && <AlertBanner variant="error" message={error} />}

      <Card>
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400">
            Carregando equipe técnica...
          </div>
        ) : technicians.length === 0 ? (
          <EmptyState
            icon={<Wrench className="w-5 h-5" />}
            title="Nenhum técnico cadastrado nesta empresa"
            description="Cadastre os técnicos de campo para atribuí-los às ordens de serviço e organizar a agenda."
            action={
              <Button
                size="sm"
                onClick={openNew}
                leftIcon={<Plus className="w-4 h-4" />}
              >
                Cadastrar Primeiro Técnico
              </Button>
            }
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {technicians.map((t) => (
              <div
                key={t.id}
                className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col justify-between gap-4"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold text-white shrink-0"
                        style={{ backgroundColor: t.calendar_color || '#0D9488' }}
                      >
                        {t.full_name.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-sm font-bold text-slate-900 truncate">
                          {t.full_name}
                        </h3>
                        <div className="text-xs text-slate-500 truncate">
                          {t.email || 'E-mail não informado'}
                        </div>
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-full text-[11px] font-medium border ${
                        t.is_active
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-500 border-slate-200'
                      }`}
                    >
                      {t.is_active ? 'Ativo' : 'Inativo'}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1">
                    {t.phone && <div>Tel.: {t.phone}</div>}
                    {t.registration_code && (
                      <div className="font-mono text-[11px] text-slate-500">
                        Registro CFT/IPEM: {t.registration_code}
                      </div>
                    )}
                  </div>

                  {t.specialties && t.specialties.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {t.specialties.map((sp) => (
                        <span
                          key={sp}
                          className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px]"
                        >
                          {sp}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="pt-2 border-t border-slate-100 space-y-1 text-[11px]">
                    <div className="flex items-center gap-1.5">
                      {t.user_id ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-800 font-medium">
                            Conta Supabase Auth vinculada
                          </span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span className="text-slate-500">
                            Vínculo automático ao criar login com este e-mail
                          </span>
                        </>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 text-slate-600">
                      <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
                      <span>
                        {t.can_view_all_company_os
                          ? 'Autorização explícita: vê todas as OS da empresa'
                          : 'Padrão RLS: vê apenas OS atribuídas a ele'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-slate-100">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => openEdit(t)}
                    leftIcon={<Edit3 className="w-3.5 h-3.5" />}
                  >
                    Configurar Técnico
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingTech ? 'Editar Técnico' : 'Novo Técnico de Campo'}
        subtitle="Credenciais, cor na agenda e política de acesso no banco (RLS)"
        footer={
          <>
            <Button variant="outline" onClick={() => setModalOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" form="tech-form" isLoading={saving}>
              Salvar Técnico
            </Button>
          </>
        }
      >
        <form id="tech-form" onSubmit={handleSave} className="space-y-4">
          {submitErr && <AlertBanner variant="error" message={submitErr} />}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputField
              label="Nome Completo"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              error={fieldErrors.full_name}
            />
            <InputField
              label="E-mail de Acesso (Supabase Auth)"
              type="email"
              placeholder="tecnico@eabalancas.com.br"
              hint="Ao cadastrar conta com este e-mail, o técnico entra automaticamente com perfil restrito."
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              error={fieldErrors.email}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <InputField
              label="Telefone / Celular"
              value={phone}
              onChange={(e) => setPhone(formatPhone(e.target.value))}
            />
            <InputField
              label="CPF"
              value={cpf}
              onChange={(e) => setCpf(formatCPF(e.target.value))}
              error={fieldErrors.document_cpf}
            />
            <InputField
              label="Registro CFT / CREA / IPEM"
              placeholder="Ex.: CFT-SP 104922"
              value={regCode}
              onChange={(e) => setRegCode(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <InputField
                label="Especialidades (separadas por vírgula)"
                placeholder="Ex.: Rodoviária, Plataforma, Analítica, Calibração RBC"
                value={specialtiesText}
                onChange={(e) => setSpecialtiesText(e.target.value)}
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-medium text-slate-700">
                Cor na Agenda
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={calendarColor}
                  onChange={(e) => setCalendarColor(e.target.value)}
                  className="h-9 w-12 rounded border border-slate-300 cursor-pointer"
                />
                <span className="font-mono text-xs text-slate-600">
                  {calendarColor}
                </span>
              </div>
            </div>
          </div>

          <TextareaField
            label="Observações"
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />

          <CheckboxField
            label="Autorização explícita para visualizar OS de outros técnicos desta empresa"
            description="Desmarcado por padrão (regra de segurança): o banco PostgreSQL restringe este técnico estritamente às OS atribuídas a ele."
            checked={canViewAllOS}
            onChange={(e) => setCanViewAllOS(e.target.checked)}
          />

          <CheckboxField
            label="Técnico ativo para novos agendamentos"
            checked={isActive}
            onChange={(e) => setIsActive(e.target.checked)}
          />
        </form>
      </Modal>
    </div>
  );
};
