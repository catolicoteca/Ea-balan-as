import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { AuthTenantProvider, useAuthTenant } from './contexts/AuthTenantContext';
import { AppShell } from './components/layout/AppShell';
import { AuthPage } from './pages/AuthPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { DashboardPage } from './pages/DashboardPage';
import { ClientsPage } from './pages/ClientsPage';
import { EquipmentsPage } from './pages/EquipmentsPage';
import { TechniciansPage } from './pages/TechniciansPage';
import { ServiceOrdersPage } from './pages/ServiceOrdersPage';
import { SchedulePage } from './pages/SchedulePage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

const AppRoutes: React.FC = () => {
  const { user, isLoading, schemaMissing, activeCompany, effectiveRole } =
    useAuthTenant();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F4F7FA] flex flex-col items-center justify-center gap-3 text-slate-600">
        <Loader2 className="w-7 h-7 animate-spin text-teal-700" />
        <span className="text-xs font-medium">
          Validando sessão e permissões multi-tenant...
        </span>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  if (schemaMissing || !activeCompany || !effectiveRole) {
    return <OnboardingPage />;
  }

  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/clientes" element={<ClientsPage />} />
        <Route path="/equipamentos" element={<EquipmentsPage />} />
        <Route path="/tecnicos" element={<TechniciansPage />} />
        <Route path="/ordens-de-servico" element={<ServiceOrdersPage />} />
        <Route path="/agenda" element={<SchedulePage />} />
        <Route path="/relatorios" element={<ReportsPage />} />
        <Route path="/configuracoes" element={<SettingsPage />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  );
};

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AuthTenantProvider>
        <AppRoutes />
      </AuthTenantProvider>
    </BrowserRouter>
  );
};

export default App;
